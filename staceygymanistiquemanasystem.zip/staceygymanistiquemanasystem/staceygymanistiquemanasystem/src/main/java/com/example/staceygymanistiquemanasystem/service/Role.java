package com.example.staceygymanistiquemanasystem.service;

public interface Role {
    void setName(String roleUser);
}
