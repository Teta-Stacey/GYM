package com.example.staceygymanistiquemanasystem.contoller;

public @interface Valid {
}
