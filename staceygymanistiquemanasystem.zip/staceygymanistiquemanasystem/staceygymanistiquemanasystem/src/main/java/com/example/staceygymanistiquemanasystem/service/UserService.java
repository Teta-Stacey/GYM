package com.example.staceygymanistiquemanasystem.service;


import com.example.staceygymanistiquemanasystem.dto.UserDto;
import com.example.staceygymanistiquemanasystem.entity.User;

import java.util.List;

public interface UserService {
    User saveUser(UserDto userDto);
    User findUserByEmail(String email);
    List<User> findAllUsers();
    UserDto getUserById(Long id);
    User updateUser(UserDto userDto);
    void deleteUser(Long id);
}
