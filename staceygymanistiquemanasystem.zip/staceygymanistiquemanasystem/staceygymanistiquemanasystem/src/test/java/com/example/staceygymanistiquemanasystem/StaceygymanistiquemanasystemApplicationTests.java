package com.example.staceygymanistiquemanasystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaceygymanistiquemanasystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
