package com.example.staceygymanistiquemanasystem.service;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceImplTest {

}